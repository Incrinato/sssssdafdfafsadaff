<p align= center</p><a href="https://cheataway.com" target="_blank"><img src="https://cdn.discordapp.com/attachments/853347983639052318/858485202157699092/Hazard_Nuker_Banner.png" alt="HazardNuker"></a>

### 2022-03-27, v1.4.7
* ` Fixed bugs`

### 2022-03-27, v1.4.6
* ` Updated Qr-code.zip url`
* ` cleaned some code`

### 2022-02-11, v1.4.5
* ` Fixed a big bug with the token grabber creator`

### 2022-02-10, v1.4.4
* ` Just bug fixes`

### 2022-02-07, v1.4.3
* ` Checks if the token is phone locked now`
* ` Removed the cancel key for every options except seizure because it really had no use and don't think anyone gonna stop mid server spamming`
* ` Neon theme looks better now, the old one was ass`
* ` Some errors are more clearer now, and easier to traceback`
* ` Added opera stable browser support`
* ` Fixed the threading a bit and improved it`
* ` General bug fixes`

### 2022-01-25, v1.4.2
* ` Finished option 11`
* ` So now you can change the users bio and hypesquad badge`

### 2022-01-23, v1.4.1
* ` Drastically changed the file size of hazard grabber.v2 + fixed bugs and made it more efficient etc...`
* ` Qr code grabber[14] now works again since discord updated it a little`
* ` Added more browser support for option [9] (login account) so if you dont have google it will try either google, edge and soon opera stable`
* ` Fixed bug were hazard grabber.v2 didnt work if you choose to obfuscated it` 

### 2022-01-19, v1.4.0
* ` New option! Changed exit to settings so you can customize alot of stuff with hazard now like themes`
* ` New option! profile changer, edit the users status, bio and hypesquad badge!` 
* ` New option! friend blocker (replaced from disable token)` 
* ` Themes! You can select a theme for hazard now, the theme will also be stored for the next time you open up hazard!`
* ` Threads! You can select amount of threads that hazard will send out! More threads = faster but dont have to many (default is 3 + the threads **don't** apply for every option)`
* ` Cancel Key! When using an option like seizure for example, you can cancel the operation at any time by pressing your cancel key! (default key is ctrl+x)`
* ` You can now choose if you want to obfuscate hazard stealer v2 (not gonna make the obfuscation op since this is a free tool)`
* ` Added option to have a server icon of you choice when spamming servers`
* ` Added option to have random server name when spamming servers (suggestion from needhelpn (https://github.com/Rdimo/Hazard-Nuker/issues/53))`
* ` All options are now 3x faster`
* ` Alot better proxy scraping`
* ` It now checks if you got the libs installed, thought I did this earlier but no`
* ` Made the webhook checker alot better`
* ` Made the token checker alot better`
* ` Made the login function (option 9) faster`
* ` Qr Code grabber now looks cleaner and grabs more info ;)`
* ` Removed the progressbar`
* ` fixed bug were seizure mode would not switch to dark mode and only stay on light`
* ` fixed bug were you couldn't install chromedriver since they removed it, so I made my own`
* ` fixed bug were you got blocked for requesting too much to scrape proxies is now fixed since hazard grabs from alot more urls`
> **THIS IS THE FIRST PART OF THE UPDATE SINCE SO MANY OF YOU WANTED IT OUT QUICKLY EXPECT ALOT OF BUGS AND IF YOU FIND ANY PLEASE TELL ME**

### 2021-11-7, v1.3.3
* ` New option! Groupchat Spammer (suggestion from JayH4x (https://github.com/Rdimo/Hazard-Nuker/issues/18))`
* ` Added proxies! dw it auto scrapes proxies for you so the whole proccess is automated`
* ` Made it web scrape the download url for auto update`
* ` New setup to make it easier to start hazard`
* ` Fixed the qr code scanner, since it got patched`
* ` Fixed bug where the servers wouldn't get left (they won't be deleted, haven't figured out how to fix that one since discord patched it)`
> **even though I use proxies you might still get ratelimited and I will fix alot better proxies and proxy system for this in the future!**

### 2021-10-27, v1.3.2
* ` Fixed Mass Report`
* ` For those wondering why my github wasn't visible it was because I got flagged for a while but I'm back now and unflagged!`

### 2021-10-16, v1.3.1
* ` New option! Create Stealer (https://github.com/Rdimo/Hazard-Token-Grabber-V2)`
* ` Should hopefully fully Support Linux Now!`
* ` Auto update now works for both compiled and source code users`
* ` Enabled logs when creating the loggers`
* ` Updated every api to v9`
* ` Fixed bug where seizure mode would go on forever after account nuker`
* ` Fixed bug where the servers wouldn't get deleted/left`

### 2021-9-26, v1.3.0
* ` Eyy source code release as promised`
* ` Fixed some stuff too but don't remember what I fixed`

### 2021-9-22, v1.2.9
* ` Made it so the title changes depending on what your doing now`
* ` Fixed a bug where the title didn't change`
* ` Fixed bug where the qr code grabber would crash`
* ` Fixed token grabber bug, yet again`

### 2021-9-19, v1.2.8
* ` New option! Mass DM, basically just dm's every friend that they have`
* ` Made it show the name instead of the id when removing friends, dms, guild etc except for when using dm spam since that was a pain to fix`
* ` All options runs 100x faster since I abuse threads now`
* ` Hazard runs alot smoother now since I cleaned up the code`
* ` Fixed a bug with the token grabber that it wouldn't install pyinstaller for you`
* ` Fixed a bug were the token grabber wouldn't grab passwords sometimes`

### 2021-9-13, v1.2.7
* ` Fixed a bug with token grabber since I forgot to remove on thing`
* ` Made it more clear when Hazard Nuker fails to update`
* ` Made it more clear on what to do with QR code grabber`

### 2021-9-13, v1.2.6
* ` Fixed a error that you couldn't create token grabber`
* ` Fixed Error Webhook a little`
* ` Made QR code grabber a little bit more clear`

### 2021-9-13, v1.2.5
* ` New option! QR Code grabber! Create a qr code and send it to users to steal their token!`
* ` Made Hazard Nuker send an error to your webhook incase you get one (easier for me to debug and you can send me the errors)`
* ` Disabled logs when logging into an account`
* ` Option 9 is not disable account instead of disable token since disable token got patched (more info https://github.com/Rdimo/Hazard-Nuker#9-disable-account)`
* ` You can now choose if you want to steal password or not`
* ` Just generally improved autoupdate`
* ` Fixed bug where the grabber would crash because it failed to get their language`
* ` Fixed bug with status changer and seizure that you would get an error sometimes`

### 2021-9-2, v1.2.4
* ` Fixed bug where you wouldn't get the password upon people running the token grabber`

### 2021-9-2, v1.2.3
* ` Fixed additional bugs`
* ` Made it check for another module and decreased the logs when creating the token grabber`

### 2021-9-2, v1.2.2
* ` Just fixed a bug were you couldn't create the token/password grabber`

### 2021-9-1, v1.2.1
* ` The token grabber now grabs password and creditcard info! The password will be sent over everytime the user updates the password/email or adds a cc (looks like this now https://imgur.com/bgDXl1F)`
* ` New option! Status changer so you can change their status to whatever you want`
* ` Added so you now see all the badges an account has when using option [7]`
* ` Made option [8] faster and just better working`
* ` Fixed so it now checks properly if you have pyinstaller installed and such`
* ` Fixed the valid webhook checker since it kinda crashed when an invalid webhook url was given`
* ` Fixed webhook spammer a bit, before the input in seconds would always add like +2-3sec`
* ` Fixed so you get the correct avatar url now for the account when using option [7]`
* ` Hazard nuker now downloads a chromedriver for you automatically`

### 2021-07-10, v1.2.0
* ` New option to delete all the private dm channels`
* ` Fixed so seizure mode is active while nuking the account so its even more annoying`
* ` Made it print slow now after almost every option`

### 2021-07-10, v1.1.9
* ` Improved mass report by quite alot:`
* ` Made the title of the cmd change and show how many reports have been sent and the errors`
* ` Better error messages`
* ` Additionally added so you can choose how many reports you wanna send`
* ` Added alot more like reloading if you put wrong report option etc`
* ` Changed the main gui a little bit and made it just more cleaner`
* ` Removed the loading at the start since it was kinda useless`
* ` Made checking for updates a loading bar instead of a slow print`

### 2021-07-09, v1.1.8
* ` Added option to delete webhook and made it as a second choice for choice [11]`
* ` improved token info by alot so now you get nitro info, billing info, avatar url and more small things`

### 2021-07-07, v1.1.7
* ` Fixed seizure mode to work while nuking the account`
* ` Fixed the Log into account actually work now (need correct driver for it)`

### 2021-07-07, v1.1.6
* ` Made auto update work a bit cleaner`
* ` You can now choose what message will be sent to every friend`
* ` You can now choose what the name of the servers will be `

### 2021-06-27, v1.1.5
* ` Added webhook spammer`
* ` Fixed the auto update, put the wrong link in before but now it works`
* ` Made it check for a valid webhook when creating the token grabber`
* ` Made the token grabbers console not popup anymore`
* ` You can now see the person set Language when using option [6]`

### 2021-06-26, v1.1.4
* ` Added Auto update functionality`
* ` Added mass report option to mass report a user`
* ` Added Token grabber creator, (https://imgur.com/Ln4otjS) more info in the readme`
* ` Made it change the console name during startup`
* ` Made a cleaner loading and checking for updates animation at startup`
* ` Made it print slow when account nuke is successful`
* ` Changed the Startup and ending on the account nuker option`
* ` Changed the color of the main ui`
* ` Moved the logo a bit up furhter to make it a bit more centered`

| 🌟Star This Repository If You Liked Hazard Nuker!|
|-------------------------------------------------|

|⚠️・ Hazard Nuker was made for educational purposes.・⚠️|
|-------------------------------------------------|

By using HazardNuker, you agree that you hold responsibility and accountability of any consequences caused by your actions

Created by Rdimo#6969 | https://cheataway.com
