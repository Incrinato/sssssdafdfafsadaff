---
name: Report A Bug
about: Report a bug to help Rdimo Make Hazard Nuker even better
title: Hazard Nuker [BUG]
labels: bug
assignees: Rdimo

---

**Describe the bug**
Try to describe how and when the bug is occuring
would be even better if you could send screenshot of it
